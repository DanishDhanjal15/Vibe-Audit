const stripe_live_key = "sk_live_1234567890abcdef12345678"
