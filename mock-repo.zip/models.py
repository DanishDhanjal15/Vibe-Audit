class User: ssn = "123-456-7890"
